/*
 * This method creates the passenger objects
*/
package flight;

public class Passenger {
    //define variables
    String name;
    String age;
    String country;
    
    //create constructors
    public Passenger(String myName, String myAge, String myCountry){
        name = myName;
        age = myAge;
        country = myCountry;
    }
}
